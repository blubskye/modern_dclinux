/* This is for i386-sequent-bsd.  The assembler probably does not
   actually work, as the support in BFD is not complete as of this
   writing.  See bfd/i386-dynix.c.  */

#define TE_DYNIX 1

#include "obj-format.h"
