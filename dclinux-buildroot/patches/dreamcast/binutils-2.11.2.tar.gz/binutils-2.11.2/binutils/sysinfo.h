typedef union {
 int i;
 char *s;
} YYSTYPE;
#define	COND	257
#define	REPEAT	258
#define	TYPE	259
#define	NAME	260
#define	NUMBER	261
#define	UNIT	262


extern YYSTYPE yylval;
