/* This header is included into every file that declares a stub function.
 * The build process looks for this header in .d files to decide whether
 * or not it needs to scan the corresponding .c file for entries to add to
 * <gnu/stubs.h>.
 */
