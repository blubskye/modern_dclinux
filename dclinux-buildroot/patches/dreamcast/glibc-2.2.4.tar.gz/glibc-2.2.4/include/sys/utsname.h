#ifndef	_SYS_UTSNAME_H
#include <posix/sys/utsname.h>

extern int __uname (struct utsname *__name);
#endif
