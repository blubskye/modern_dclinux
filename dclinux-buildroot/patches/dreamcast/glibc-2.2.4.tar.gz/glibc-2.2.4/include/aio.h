#ifndef _AIO_H
#include <rt/aio.h>

/* Now define the internal interfaces.  */ 
extern void __aio_init (__const struct aioinit *__init);
#endif
