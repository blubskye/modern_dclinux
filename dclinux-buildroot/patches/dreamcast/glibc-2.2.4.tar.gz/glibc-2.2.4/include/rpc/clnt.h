#ifndef _RPC_CLNT_H
#include <sunrpc/rpc/clnt.h>

/* Now define the internal interfaces.  */
extern int _openchild (const char *command, FILE **fto, FILE **ffrom);

#endif
