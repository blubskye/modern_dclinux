/* Environment variable to be removed for SUID programs.  */
#define UNSECURE_ENVVARS \
  "GCONV_PATH",								      \
  "HOSTALIASES",							      \
  "LOCALDOMAIN",							      \
  "LOCPATH",								      \
  "MALLOC_TRACE",							      \
  "NLSPATH",								      \
  "RESOLV_HOST_CONF",							      \
  "RES_OPTIONS",							      \
  "TMPDIR",								      \
  "TZDIR"
