#ifndef __ASSEMBLY__
extern void _start (void);
#endif

#define ENTRY_POINT _start
